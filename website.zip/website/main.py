from flask import Flask, render_template, request
import requests

app = Flask(__name__, static_folder = 'static', static_url_path = "")

@app.route("/")
def home():
    return render_template("index.html")
@app.route("/index.html")
def home2():
    return render_template("index.html")

@app.route("/search.html", methods = ["POST"])
def search():
    data = request.form
    URL = "https://developer.uspto.gov/ibd-api/v1/patent/application"
    results = []
    corpus = []
    domain = []
    description = []
    string = ""
    searchtext = request.form['searchkey']
    dataQuery = requests.get(url= URL,params={'searchText':searchtext,'start':'0','rows':100})
    data = dataQuery.json()
    for x in range(0,len(data['response']['docs'])):
        results.append(data['response']['docs'][x]['title'])

    r = requests.get("https://autocomplete.clearbit.com/v1/companies/suggest?query=:"+searchtext)
    data = r.json()

    for i in range(len(data)):
        corpus.append(str(data[i]['name']))
        domain.append(str(data[i]['domain']))

    API_Key = "f0c18f8a4aadc1c754026ec7d80bce2e"
    API_Secret = "3b18b9548dfcfb112d08d3be53bd6142"

    r2 = requests.get("https://www.amee.com/api/companies?company_name="+searchtext,auth=(API_Key,API_Secret))
    data2 = r2.json()
    data2 = data2["companies"]

    for i in range(len(data2)):
        description.append(str(data2[i]["line_of_business"]))

    return render_template("search.html", string = results, data = corpus, domain = domain, description = description)


if __name__ == "__main__":
    app.run(debug=True)
